﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;

namespace UIGeiCar___Nairobi
{
    public partial class UIGeiCar : Form
    {
        TcpClient clientSocket = new TcpClient();
        NetworkStream nwStream;
        Boolean bConnected = false;
        Boolean platooning_mode = false; //hooking 
        Boolean waiting_mode = false;
        //Boolean 

        public UIGeiCar()
        {
            InitializeComponent();
            pictureBox3.Visible = false;
        }


        private void Bconnect_Click(object sender, EventArgs e)
        {
            try
            {
                clientSocket.Connect(ip.Text, 6666);
                bconnect.Text = "Connected";
                bconnect.Enabled = false;
                nwStream = clientSocket.GetStream();
                bConnected = true;
                EnableAll();
                ip.Enabled = false;
                Receive();
            }
            catch (SocketException ex)
            {
                bConnected = false;
                bconnect.Text = "Failed to connect";
                Console.WriteLine(ex.Message);
            }
        }

        private void EnableAll()
        {
            bforward.Enabled = true;
            bright.Enabled = true;
            SpdBar.Enabled = true;
            bleft.Enabled = true;
            bbackward.Enabled = true;
            bstopMOV.Enabled = true;
            bstopSTE.Enabled = true;
            //towing.Enable = true; 
        }

        private void DisableAll()
        {
            bforward.Enabled = false;
            bright.Enabled = false;
            SpdBar.Enabled = false;
            bleft.Enabled = false;
            bbackward.Enabled = false;
            bstopMOV.Enabled = false;
            bstopSTE.Enabled = false;
            //towing.Enable = false;
        }

        async void Receive()
        {

            int cmpt = 0;
            if (bConnected)
            {
                while (clientSocket.Connected)
                {
                    byte[] myReadBuffer = new byte[2048];
                    await nwStream.ReadAsync(myReadBuffer, 0, myReadBuffer.Length);
                    String st = Encoding.UTF8.GetString(myReadBuffer);
                    String[] msgs = st.Split(';');

                    foreach (String msg in msgs)
                    {
                        Console.WriteLine(msg);
                        String[] elt = msg.Split(':');
                        switch (elt[0])
                        {
                            
                            case "ERR":
                                //Display_label_off();
                                if (elt[1].Contains('a'))
                                {
                                    //eWARNING_obstacle.Visible = true;
                                    mag_imm.Image = Properties.Resources.led_rouge;
                                    Info_error.Text = "Magnetic Fail";
                                }
                                if (elt[1].Contains('b'))
                                {
                                    front_imm.Image = Properties.Resources.led_rouge;
                                    Info_error.Text = "US slave Fail";
                                }
                                if (elt[1].Contains('c'))
                                {
                                    back_imm.Image = Properties.Resources.led_rouge;
                                    Info_error.Text = "US master Fail";
                                }
                                if (elt[1].Contains('a') && elt[1].Contains('b') && elt[1].Contains('c'))
                                {
                                    pictureBox3.Image = Properties.Resources.barre_no;
                                    Info_error.Text = "All Sensors Fail";
                                }
                                else
                                {
                                    pictureBox3.Image = Properties.Resources.barre_what;
                                }
                                break;
                            default:
                                cmpt = (cmpt + 1) % 100;
                                break;
                        }
                        if (cmpt == 0)
                        {
                            switch (elt[0])
                            {
                                case "TOWSTATE": 
                                    towing.BackgroundImage = Properties.Resources.ON;
                                    pictureBox3.Visible = true;
                                    break;
                                case "MAG":
                                    mag_value.Text = elt[1];
                                    break;
                                case "UFC_slave":
                                    eUSFC.Text = elt[1];
                                    break;
                                case "URC":
                                    eUSRC.Text = elt[1];
                                    break;
                                case "BAT":
                                    eBAT.Text = elt[1];
                                    break;
                            }
                        }
                    }
                }
            }
        }

        private void Bright_Click(object sender, EventArgs e)
        {
            if (bConnected)
            {
                byte[] bytes = Encoding.ASCII.GetBytes("STE:" + "right;");
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

        private void Bbackward_Click(object sender, EventArgs e)
        {
            if (bConnected)
            {
                byte[] bytes = Encoding.ASCII.GetBytes("MOV:" + "backward;");
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

        private void Bleft_Click(object sender, EventArgs e)
        {
            if (bConnected)
            {
                byte[] bytes = Encoding.ASCII.GetBytes("STE:" + "left;");
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

        private void Bforward_Click(object sender, EventArgs e)
        {
            if (bConnected)
            {
                byte[] bytes = Encoding.ASCII.GetBytes("MOV:" + "forward;");
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

        private void BstopSTE_Click(object sender, EventArgs e)
        {
            if (bConnected)
            {
                byte[] bytes = Encoding.ASCII.GetBytes("STE:" + "stop;");
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

        private void BstopMOV_Click(object sender, EventArgs e)
        {
            if (bConnected)
            {
                byte[] bytes = Encoding.ASCII.GetBytes("MOV:" + "stop;");
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

        private void UIGeiCar_KeyDown(object sender, KeyEventArgs e)
        {
            byte[] bytes = Encoding.ASCII.GetBytes("STE:" + "stop;");
            if (bConnected)
            {
                switch (e.KeyCode)
                {
                    case Keys.Down:
                        bytes = Encoding.ASCII.GetBytes("MOV:" + "backward;");
                        break;
                    case Keys.Up:
                        bytes = Encoding.ASCII.GetBytes("MOV:" + "forward;");
                        break;
                    case Keys.Left:
                        bytes = Encoding.ASCII.GetBytes("STE:" + "left;");
                        break;
                    case Keys.Right:
                        bytes = Encoding.ASCII.GetBytes("STE:" + "right;");
                        break;
                }
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

        private void UIGeiCar_KeyUp(object sender, KeyEventArgs e)
        {
            byte[] bytes = Encoding.ASCII.GetBytes("STE:" + "stop;");
            if (bConnected)
            {
                switch (e.KeyCode)
                {
                    case Keys.Down:
                    case Keys.Up:
                        bytes = Encoding.ASCII.GetBytes("MOV:" + "stop;");
                        break;
                    case Keys.Left:
                    case Keys.Right:
                        bytes = Encoding.ASCII.GetBytes("STE:" + "stop;");
                        break;
                }
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

        private void UIGeiCar_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void SpdBar_ValueChanged(object sender, EventArgs e)
        {
            byte[] bytes = Encoding.ASCII.GetBytes("SPE:" + SpdBar.Value.ToString() + ";");
            nwStream.Write(bytes, 0, bytes.Length);
            eSPD.Text = SpdBar.Value.ToString();
        }

        private void KbCtrl_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            byte[] bytes = Encoding.ASCII.GetBytes("STE:" + "stop;");
            if (bConnected)
            {
                switch (e.KeyCode)
                {
                    case Keys.Down:
                        bytes = Encoding.ASCII.GetBytes("MOV:" + "backward;");
                        break;
                    case Keys.Up:
                        bytes = Encoding.ASCII.GetBytes("MOV:" + "forward;");
                        break;
                    case Keys.Left:
                        bytes = Encoding.ASCII.GetBytes("STE:" + "left;");
                        break;
                    case Keys.Right:
                        bytes = Encoding.ASCII.GetBytes("STE:" + "right;");
                        break;
                }
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

        private void BmodePlatooning_Click(object sender, EventArgs e) //bmodeplatooning -> start_hooking 
        {
            if (bConnected) 
            {
                if (platooning_mode == false && waiting_mode == false)
                {
                   /* byte[] bytes = Encoding.ASCII.GetBytes("HOO:" + "on;"); // PLA = HOO
                    BmodePlatooning.BackgroundImage = Properties.Resources.wait;
                    nwStream.Write(bytes, 0, bytes.Length);
                    platooning_mode = false;
                    waiting_mode = true;*/

                    byte[] bytes = Encoding.ASCII.GetBytes("HOO:" + "request;");
                    BmodePlatooning.BackgroundImage = Properties.Resources.wait;
                    nwStream.Write(bytes, 0, bytes.Length);
                    platooning_mode = false;
                    waiting_mode = true;

                }
                else
                {
                    if (platooning_mode == true || waiting_mode == true)
                    {
                        byte[] bytes = Encoding.ASCII.GetBytes("PLA:" + "off;");
                        BmodePlatooning.BackgroundImage = Properties.Resources.OFF;
                        nwStream.Write(bytes, 0, bytes.Length);
                        platooning_mode = false;
                        waiting_mode = false;
                        //Display_label_off();
                    }
                }

            }
        }

        private void Bdisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                clientSocket.Close();
                bconnect.Enabled = true;
                bdisconnect.Enabled = false;
                bConnected = false;
                ip.Enabled = true;
                DisableAll();
            }
            catch (SocketException ex)
            {
                bConnected = true;
                bconnect.Text = "Failed to disconnect";
                Console.WriteLine(ex.Message);
            }
        }

      /*  private void BPlat_accept_Click(object sender, EventArgs e)
        {
            if (waiting_mode == true)
            {
                byte[] bytes = Encoding.ASCII.GetBytes("PLA:" + "yes;");
                BmodePlatooning.BackgroundImage = Properties.Resources.ON;
                nwStream.Write(bytes, 0, bytes.Length);
                waiting_mode = false;
                platooning_mode = true;
                /*ILIDAR.Visible = true;
                eLIDAR.Visible = true;
                car_detected.Visible = false;
                BPlat_accept.Enabled = false;
                BPlat_refuse.Enabled = false;
                BPlat_accept.Visible = false;
                BPlat_refuse.Visible = false;
            }
        }

        private void BPlat_refuse_Click(object sender, EventArgs e)
        {
            if (waiting_mode == true)
            {
                byte[] bytes = Encoding.ASCII.GetBytes("PLA:" + "no;");
                BmodePlatooning.BackgroundImage = Properties.Resources.wait;
                nwStream.Write(bytes, 0, bytes.Length);
                waiting_mode = true;
                platooning_mode = false;
                /*ILIDAR.Visible = true;
                eLIDAR.Visible = true;
                car_detected.Visible = false;
                BPlat_refuse.Enabled = true;
                BPlat_accept.Visible = true;
                BPlat_refuse.Visible = true;
            }
        }*/

      /*  private void Display_label_on()
        {
            /*ILIDAR.Visible = true;
            eLIDAR.Visible = true;
            car_detected.Visible = true;
            BPlat_accept.Enabled = true;
            BPlat_refuse.Enabled = true;
            BPlat_accept.Visible = true;
            BPlat_refuse.Visible = true;
        }

        private void Display_label_off()
        {
            /*ILIDAR.Visible = false;
            eLIDAR.Visible = false;
            car_detected.Visible = false;
            BPlat_accept.Enabled = false;
            BPlat_refuse.Enabled = false;
            BPlat_accept.Visible = false;
            BPlat_refuse.Visible = false;
        }*/

        private void Lost_car_process()
        {
            byte[] bytes = Encoding.ASCII.GetBytes("PLA:" + "off;");
            BmodePlatooning.BackgroundImage = Properties.Resources.OFF;
            nwStream.Write(bytes, 0, bytes.Length);
            platooning_mode = false;
            waiting_mode = false;
        }

        //private void Start_hook_Click(object sender, EventArgs e) // private void Towing_Click(object sender, EventArgs e)
        private void Towing_Click(object sender, EventArgs e)
        {
            if (bConnected)
            {
                byte[] bytes = Encoding.ASCII.GetBytes("TOW:" + "request;"); 
                towing.BackgroundImage = Properties.Resources.wait;
                nwStream.Write(bytes, 0, bytes.Length);
            }
        }

       /* private void Info_error_Click(object sender, EventArgs e)
        {
          
        }

          private void IUSLC_Click(object sender, EventArgs e) //?? US sensor of the 2 car 
          {

          }

          private void InfoLayout_Paint(object sender, PaintEventArgs e)
          {

          }

          private void UIGeiCar_Load(object sender, EventArgs e)
          {

          } */
    }
}
